package com.example.order.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.order.dto.PlaceOrderReq;
import com.example.order.entity.Order;
import com.example.order.entity.Product;
import com.example.order.entity.User;
import com.example.order.exception.GlobalExceptionHandler;
import com.example.order.repository.OrderRepository;
import com.example.order.repository.ProductRepository;
import com.example.order.repository.UserRepository;

@Service
public class OrderService {



    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private ProductRepository productRepository;
	
	
	public Order placeOrder(PlaceOrderReq request) throws GlobalExceptionHandler {
        Optional<User> user = userRepository.findById(request.getUserId());
        if (user.isEmpty()) {
            throw new GlobalExceptionHandler("User not found");
        }

        Optional<Product> product = productRepository.findById(request.getProductId());
        if (product.isEmpty()) {
            throw new GlobalExceptionHandler("Product not found");
        }

        Product availableProduct = product.get();
        if (availableProduct.getStock() < request.getQuantity()) {
            throw new GlobalExceptionHandler("Product is out of stock");
        }

        availableProduct.setStock(availableProduct.getStock() - request.getQuantity());
        productRepository.save(availableProduct);

        Order order = new Order(user.get(), availableProduct, request.getQuantity());
        return orderRepository.save(order);
    }
	
}
