package com.example.order.exception;

public class GlobalExceptionHandler extends Exception {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3126437991448967319L;
	private String excption;

	public GlobalExceptionHandler(String excption) {
		
		this.excption = excption;
	}
	
	
	
}
